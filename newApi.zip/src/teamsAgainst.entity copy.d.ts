export declare class TeamsAgainst {
    id: number;
    name: string;
}
