export declare class Matchs {
    id: number;
    against: number;
    comp: number;
    round: string;
    homeScore: number;
    awayScore: number;
    isHomeMatch: boolean;
    date: string;
    isPlayed: boolean;
    YTLink: string;
}
