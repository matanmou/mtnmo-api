export declare class PlayersRating {
    matchID: number;
    playerID: number;
    rating: number;
    numOfVotes: number;
}
