export declare class IplPredictPicks {
    id: string;
    predictName: string;
    userName: string;
    date: string;
    season: number;
    p1: number;
    p2: number;
    p3: number;
    p4: number;
    p5: number;
    p6: number;
    p7: number;
    p8: number;
    p9: number;
    p10: number;
    p11: number;
    p12: number;
    p13: number;
    p14: number;
}
