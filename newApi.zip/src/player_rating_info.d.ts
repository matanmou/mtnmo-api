export declare class PlayerRatingInfo {
    playerID: number;
    rating: number;
    constructor(playerID: number, rating: number);
}
