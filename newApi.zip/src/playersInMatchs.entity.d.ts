export declare class PlayersInMatchs {
    MatchId: number;
    p1ID: number;
    p2ID: number;
    p3ID: number;
    p4ID: number;
    p5ID: number;
    p6ID: number;
    p7ID: number;
    p8ID: number;
    p9ID: number;
    p10ID: number;
    p11ID: number;
    p12ID: number;
    p13ID: number;
    p14ID: number;
    p15ID: number;
    p16ID: number;
    coachID: number;
}
