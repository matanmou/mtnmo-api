export declare class Players {
    id: number;
    name: string;
    num: number;
    pos: string;
}
