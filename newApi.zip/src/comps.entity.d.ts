export declare class Comps {
    id: number;
    name: string;
}
