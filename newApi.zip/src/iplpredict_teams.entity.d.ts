export declare class IplPredictTeams {
    id: number;
    teamName: string;
    pColor: string;
    sColor: string;
}
