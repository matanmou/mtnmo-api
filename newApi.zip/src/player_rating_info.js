"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlayerRatingInfo = void 0;
class PlayerRatingInfo {
    constructor(playerID, rating) {
        this.playerID = playerID;
        this.rating = rating;
    }
}
exports.PlayerRatingInfo = PlayerRatingInfo;
//# sourceMappingURL=player_rating_info.js.map