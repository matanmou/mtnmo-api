import { MysqlConnectionOptions } from 'typeorm/driver/mysql/MysqlConnectionOptions';
declare const config: MysqlConnectionOptions;
export default config;
